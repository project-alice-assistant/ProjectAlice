#ifndef INTERFACE_H
#define INTERFACE_H

#ifdef __cplusplus
#include <cstdint>
#include <string>
#include <vector>
#else
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#endif // !__cplusplus

#ifdef __cplusplus
extern "C"
{
#endif

  const char* snips_kaldi_version();

  typedef struct CLogMessageEnvelope
  {
    const char* func;
    const char* file;
    int32_t severity;
    int32_t line;
  } CLogMessageEnvelope;

  typedef struct OnlineIvectorExtractionParameters
  {
    const char* lda_mat_rxfilename;
    const char* global_cmvn_stats_rxfilename;
    const char* splice_config_rxfilename;
    const char* cmvn_config_rxfilename;
    const char* diag_ubm_rxfilename;
    const char* ivector_extractor_rxfilename;
    int32_t ivector_period;
    int32_t num_gselect;
    float min_post;
    float posterior_scale;
    float max_count;
    float max_remembered_frames;
  } OnlineIvectorExtractionParameters;

  typedef struct OpaqueDecoder OpaqueDecoder;
  typedef struct OpaqueModel OpaqueModel;
  typedef struct OpaqueFeatureComputer OpaqueFeatureComputer;
  typedef struct OpaqueOnlineResampler OpaqueOnlineResampler;

  // CArray API
  typedef struct CArray
  {
    void** data;
    void (*data_deallocator)(void* data, size_t length);
    size_t length;
    size_t max;
  } CArray;

  CArray* carray_new(size_t initsize);
  int carray_set_size(CArray* array, size_t new_size);
  int carray_add(CArray* array, void* data, unsigned int* indx);
  size_t carray_count(CArray* array);
  void* carray_get(CArray* array, size_t indx);
  void carray_destroy(CArray* array);

  // NNet3Online API

  typedef struct CToken
  {
    const char* value;
    float confidence;
    float time[2];
  } CToken;

  typedef struct CRecognitionResult
  {
    char* decoded_string;
    float likelihood;
    CArray /*Carray<CToken*>*/* tokens;
  } CRecognitionResult;

  typedef struct CPairEntity
  {
    const char* filename;
    int32_t label;
  } CPairEntity;

  typedef struct CPairWordPronunciation
  {
    const char* word;
    const char* pronunciation;
  } CPairWordPronunciation;

  void recognition_result_destroy(CRecognitionResult* result);
  void token_destroy(CToken* token);
  void pair_entity_destroy(CPairEntity* mapping);
  void pair_word_pronunciation(CPairWordPronunciation* pronunciation);

  OpaqueModel* nnet3model_create_static(
    const OnlineIvectorExtractionParameters* const ivector_params,
    const char* word_syms_filename,
    const char* model_in_filename,
    const char* fst_in_str);

  OpaqueModel* nnet3model_create_dynamic_v1(
    const OnlineIvectorExtractionParameters* const ivector_params,
    const char* word_syms_filename,
    const char* model_in_filename,
    const char* left_fst_filename,
    const char* right_fst_filename,
    const CPairEntity* entities_fst_map,
    size_t entities_count,
    size_t cache_size_dynamic);

  OpaqueModel* nnet3model_create_dynamic_v2(
    const OnlineIvectorExtractionParameters* const ivector_params,
    const char* word_syms_filename,
    const char* model_in_filename,
    const char* left_fst_filename,
    const char* right_fst_filename,
    const char* u_fst_filename,
    const CPairEntity* entities_fst_map,
    size_t entities_count,
    size_t cache_size_dynamic,
    size_t constant_cache_size);

  void nnet3model_destroy(OpaqueModel* model);

  OpaqueDecoder* nnet3online_create(float beam,
                                    int32_t max_active,
                                    int32_t min_active,
                                    float lattice_beam,
                                    float acoustic_scale,
                                    OpaqueModel* model);

  void nnet3online_destroy(OpaqueDecoder* o);

  void nnet3online_start_decoding(OpaqueDecoder* o);

  int32_t nnet3online_decode(OpaqueDecoder* o,
                             float samp_freq,
                             int32_t num_frames,
                             const float* frames,
                             bool do_endpointing);

  int32_t nnet3online_num_frames_decoded(OpaqueDecoder* o);

  CArray* /*CArray<CRecognitionResult>*/
  nnet3online_get_decoding_results(OpaqueDecoder* o,
                                   int32_t best_count,
                                   bool end_of_utterance);
  CArray* /*CArray<CRecognitionResult>*/
  nnet3online_get_decoding_results_mbr(OpaqueDecoder* w,
                                       bool end_of_utterance,
                                       float unk_threshold,
                                       float unk_proba);

  void nnet3online_finalize_decoding(OpaqueDecoder* o);

  void nnet3online_clean_up(OpaqueDecoder* o);

  float nnet3online_sample_rate(OpaqueDecoder* o);

  void nnet3online_set_endpointing_rule(OpaqueDecoder* o,
                                        int32_t rule_number,
                                        bool must_contain_nonsilence,
                                        float min_trailing_silence,
                                        float max_relative_cost,
                                        float min_utterance_length);

  void nnet3online_set_use_final_probs(OpaqueDecoder* o, bool use_final_probs);

  // OnlineFeatureComputer API
  OpaqueFeatureComputer* onlinefeaturecomputer_create(int32_t num_mel_bins,
                                                      float samp_freq,
                                                      float frame_shift_ms,
                                                      float frame_length_ms,
                                                      float dither,
                                                      float preemph_coeff,
                                                      const char* oindow_type,
                                                      int32_t num_ceps,
                                                      bool use_energy,
                                                      float energy_floor,
                                                      bool raw_energy,
                                                      float cepstral_lifter,
                                                      float mel_low_freq);

  void onlinefeaturecomputer_destroy(OpaqueFeatureComputer* o);

  CArray* /* CArray<CArray<float*>> */
  onlinefeaturecomputer_accept_waveform(OpaqueFeatureComputer* o,
                                        float samp_freq,
                                        int32_t num_frames,
                                        const float* frames);

  void onlinefeaturecomputer_cleanup(OpaqueFeatureComputer* o);

  // LogHandler API

  typedef void (*CLogHandler)(const CLogMessageEnvelope* envelope,
                              const char* message);

  void set_kaldi_log_handler(CLogHandler);

  void injection_augment_hcl_from_pron_string(
    const char* resources_injections_filename,
    const char* hcl_filename,
    const char* words_filename,
    const char* alternate_acoustic_model_filename,
    const CPairWordPronunciation* extra_lexicon_string,
    size_t extra_lexicon_size,
    bool add_bies,
    const char* u_filename);

  // OnlineResampler API

  OpaqueOnlineResampler* online_resampler_create(int32_t input_sample_rate,
                                                 int32_t output_sample_rate,
                                                 float lowpass_freq_ratio,
                                                 int32_t num_zeros);
  void online_resampler_destroy(OpaqueOnlineResampler* resampler);
  void online_resampler_accept_waveform(OpaqueOnlineResampler* resampler,
                                        int32_t samp_freq,
                                        int32_t num_frames,
                                        float* frames,
                                        bool flush,
                                        int32_t* num_resampled_frames,
                                        float** resampled_frames);
  void online_resampler_reset(OpaqueOnlineResampler* resampler);

  void arpa_to_fst(const char* arpa_filename,
                   const char* words_filename,
                   const char* output_fst_filename,
                   const char* bos_symbol,
                   const char* eos_symbol,
                   const char* disambig_symbol);

#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif // INTERFACE_H
